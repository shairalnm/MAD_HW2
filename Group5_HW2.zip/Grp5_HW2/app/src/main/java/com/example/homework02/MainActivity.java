package com.example.homework02;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {



    SeekBar asyncCountSeekbar;
    TextView asyncCountNumber;
    SeekBar asyncLengthSeekbar;
    TextView asyncLengthNumber;
    ProgressDialog progressDialog;
    int asyncCount = 1;
    int asyncLength = 7;
    static String Akey = "AsyncTask";
    ArrayList<String> generatedPasswordAsync;
    Handler handler;

    Intent intent;
    static int progress = 0;
    SeekBar tvSeekbar;
    TextView tcNumber;
    SeekBar tlseekbar;
    TextView tlNumber;
    int tc = 1;
    int tl = 7;
    static String tkey = "Threads";
    ArrayList<String> generatedPasswordThread;

    static final int STATUS_START = 0;
    static final int STATUS_PROGRESS = 1;
    static final int STATUS_STOP = 2;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override

    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Password Generator");

        tvSeekbar = findViewById(R.id.threadCount_seekBar);
        tcNumber = findViewById(R.id.threadCountNum);
        tlseekbar = findViewById(R.id.threadLength_seekBar);
        tlNumber = findViewById(R.id.threadLengthNum);
        tcNumber.setText("1");
        tlNumber.setText("7");
        tvSeekbar.setMin(1);
        tvSeekbar.setMax(10);
        tlseekbar.setMin(7);
        tlseekbar.setMax(23);
        tvSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tcNumber.setText(progress + "");
                tc = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        tlseekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tlNumber.setText(progress + "");
                tl = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        asyncCountSeekbar = findViewById(R.id.asyncCount_seekbar);
        asyncLengthSeekbar = findViewById(R.id.asyncLength_seekBar);
        asyncCountNumber = findViewById(R.id.asyncCountNum);
        asyncLengthNumber = findViewById(R.id.asyncLengthNum);
        asyncCountNumber.setText("1");
        asyncLengthNumber.setText("7");
        asyncCountSeekbar.setMin(1);
        asyncCountSeekbar.setMax(10);
        asyncLengthSeekbar.setMin(7);
        asyncLengthSeekbar.setMax(23);
        asyncCountSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                asyncCountNumber.setText(progress + "");
                asyncCount = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        asyncLengthSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                asyncLengthNumber.setText(progress + "");
                asyncLength = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        final ExecutorService threadPool;
        threadPool = Executors.newFixedThreadPool(2);

        findViewById(R.id.generatePassword_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tc == 0 || tl == 0 || asyncCount == 0 || asyncLength == 0) {
                    Toast.makeText(getApplicationContext(), "Set Count and Length!", Toast.LENGTH_SHORT).show();
                } else {
                    threadPool.execute(new generatePasswordThread());
                    new generatePasswordAsync().execute();
                    intent = new Intent(MainActivity.this, activity_GeneratedPasswords.class);
                    progressDialog = new ProgressDialog(MainActivity.this);
                    progressDialog.setMessage("Generating Passwords");
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
//                    progressDialog.setMax(asyncCount > tc ? asyncCount : tc);
                    progressDialog.setMax(asyncCount + tc);
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    progress = 0;
                }
            }
        });

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                try {
                    if (msg.getData().getInt("ThreadProgress") > msg.getData().getInt("AsyncProgress")) {
                        progress += 1;
                        progressDialog.setProgress(progress);
                    } else if (msg.getData().getInt("ThreadProgress") < msg.getData().getInt("AsyncProgress")) {
                        progress += 1;
                        progressDialog.setProgress(progress);
                    }

//                Log.d("demo", msg.getData().getInt("ThreadProgress") + " -- Thread");
//                Log.d("demo", msg.getData().getInt("AsyncProgress") + " -- Async");
//                Log.d("demo", "------- ----------- --- ---------");

                    if (msg.getData().getInt("AsyncStatus") == 1) {
                        generatedPasswordAsync = msg.getData().getStringArrayList(Akey);
                        intent.putExtra(Akey, generatedPasswordAsync);
                    } else if (msg.getData().getInt("ThreadStatus") == 1) {
                        generatedPasswordThread = msg.getData().getStringArrayList(tkey);
                        intent.putExtra(tkey, generatedPasswordThread);
                    }
                    if (generatedPasswordAsync != null && generatedPasswordThread != null) {
                        startActivity(intent);
                        progressDialog.dismiss();
                        asyncCountSeekbar.setProgress(0);
                        asyncLengthSeekbar.setProgress(0);
                        tvSeekbar.setProgress(0);
                        tlseekbar.setProgress(0);
                        generatedPasswordThread = null;
                        generatedPasswordAsync = null;
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Oops! Something went wrong", Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
    }

    public class generatePasswordThread implements Runnable {
        @Override
        public void run() {
            ArrayList<String> generatedPasswordThread = new ArrayList<>();
            for (int i = 0; i <= tc; i++) {
                generatedPasswordThread.add(Util.getPassword(tl));
                Message message = new Message();
                Bundle bundle = new Bundle();
                bundle.putInt("ThreadProgress", i);
                message.setData(bundle);
                handler.sendMessage(message);
            }
            Message message = new Message();
            Bundle bundle = new Bundle();
            bundle.putInt("ThreadStatus", 1);
            bundle.putStringArrayList(tkey, generatedPasswordThread);
            message.setData(bundle);
            handler.sendMessage(message);
        }
    }

    public class generatePasswordAsync extends AsyncTask<Integer, Integer, Integer> {
        @Override
        protected void onProgressUpdate(Integer... values) {
            progressDialog.setProgress(values[0]);
        }

        @Override
        protected Integer doInBackground(Integer... integers) {
            ArrayList<String> generatePasswordAsync = new ArrayList<>();
            for (int i = 0; i <= asyncCount; i++) {
                generatePasswordAsync.add(Util.getPassword(asyncLength));
                Message message = new Message();
                Bundle bundle = new Bundle();
                bundle.putInt("AsyncProgress", i);
                message.setData(bundle);
                handler.sendMessage(message);
            }
            Message message = new Message();
            Bundle bundle = new Bundle();
            bundle.putInt("AsyncStatus", 1);
            bundle.putStringArrayList(Akey, generatePasswordAsync);
            message.setData(bundle);
            handler.sendMessage(message);
            return 0;
        }
    }

}
